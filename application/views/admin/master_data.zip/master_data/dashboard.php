	<?php $this->load->view('admin/master_data/left_menu');?>
    <div class="centercontent">
        <div id="contentwrapper" class="contentwrapper">
        </div>
    </div>